from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Order:
    def __init__(self, order):
        self.id = order['id']
        self.name = order['name']
        self.cookie_type = order['cookie_type']
        self.boxes = order['boxes']
        self.updated_at = order['updated_at']
        self.created_at = order['created_at']

    @classmethod
    def get_all(cls):
        orderlist=[]
        query='SELECT * from cookie_orders;'
        orders=connectToMySQL('cookie_orders').query_db(query)
        for i in orders:
            orderlist.append(cls(i))
        return orderlist

    @classmethod
    def get_one(cls, order_id):
        query = "SELECT * from cookie_orders WHERE id = %(id)s;"
        data = {
            "id": order_id
        }
        result = connectToMySQL('cookie_orders').query_db(query, data)
        if result:
            order = result[0]
            return order
        return False

    @classmethod
    def save(cls,order):
        query= '''INSERT into cookie_orders (name, cookie_type, boxes) VALUES (%(name)s, %(cookie_type)s, %(boxes)s);'''
        result=connectToMySQL('cookie_orders').query_db(query, order)
        return result

    @classmethod
    def create(cls, cookie_order):
        query='''INSERT into cookie_orders (name, cookie_type, boxes) VALUES (%(name)s, %(cookie_type)s, %(boxes)s);'''
        result=connectToMySQL('cookie_orders').query_db(query, cookie_order)
        return result

    @classmethod
    def update(cls, cookie_order):
        query= '''UPDATE cookie_orders SET name=%(name)s, cookie_type=%(cookie_type)s, boxes=%(boxes)s WHERE id=%(id)s;'''
        result=connectToMySQL('cookie_orders').query_db(query, cookie_order)
        return result

    @classmethod
    def error_check(cls, cookie_order):
        validity = True
        if len(cookie_order["name"]) <= 0 or len(cookie_order["cookie_type"]) <= 0 or len(cookie_order["boxes"]) <= 0:
            validity = False
            flash("All fields required")
            return validity
        if len(cookie_order["name"]) < 3:
            validity = False
            flash("Name must be 3 characters or more")
        if len(cookie_order["cookie_type"]) < 3:
            validity = False
            flash("Cookie type must be 3 characters or more")
        if int(cookie_order["boxes"]) < 1 or int(cookie_order["boxes"]) > 99:
            validity = False
            flash("Number of boxes must be between 0 and 100")
        return validity

    @classmethod
    def delete(cls,data):
        query  = "DELETE FROM cookie_orders WHERE id = %(id)s;"
        return connectToMySQL('cookie_orders').query_db(query,data)