from flask import Flask, render_template, session, redirect, request
from flask_app import app
from flask_app.models.cookie_order import Order

@app.route("/")
def index():
    return redirect('/home')

@app.route('/home')
def homepage():
    orders=Order.get_all()
    return render_template('home.html',orders=orders)



@app.route('/new')
def new():
    return render_template('new_order.html')

@app.route('/edit/<int:id>')
def edit(id):
    order = Order.get_one(id)
    return render_template('edit_order.html', order=order)



@app.route('/home',methods=['POST'])
def create():
    cookie_order = request.form
    if not Order.error_check(cookie_order):
        return redirect("/new")
    Order.create(cookie_order)
    return redirect('/')

@app.route('/edit/<int:id>',methods=['POST'])
def update(id):
    cookie_order = request.form
    if not Order.error_check(cookie_order):
        return redirect(f"/edit/{id}")
    Order.update(cookie_order)
    return redirect('/')

@app.route('/delete/<int:id>')
def delete(id):
    data ={
        'id': id
    }
    Order.delete(data)
    return redirect('/')
